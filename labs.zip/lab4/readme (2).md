# ЗВІТ 
з лабораторної роботи № 4 
з дисципліни «Веб-програмування» 
на тему: «Робота з PHP-фреймворками»

Підготував Селюков Сергій


Хід роботи
***
У цій лабораторній роботі буде створено міні-вебсайт на основі Yii2 фреймворка. База даних у цьому проекті використовуватися не буде. Це буде сайт з декількома інформаційними сторінками.

Продовжимо працювати з сервером XAMPP, за допомогою якого є зв’язок сайту з браузером.  
 Тепер до всього цього додамо ще фреймворк Yii2, який треба завантажити та встановити.
 Для початку зазначу, чому мій вибір був зроблений на користь Yii2. 
Вивчається цей фреймворк легко, в порівнянні з іншими при мінімальних знаннях ООП.

Плюси:

- Легко вивчається, низький старт розробки

- Має багато вбудованих рішень для інтерфейсів

- Чудовий генератор моделей, контролерів

Тепер завантажуємо Composer з офіційного сайту Yii2.

 
Офіційний сайт Yii
 
 
 Вибір налаштувань Composera
 

 
Завершення установки Composer

Перевіримо налаштування Composerу в командному рядку за допомогою команди composer.
 

 
 Базові дані про встановлений композер
 
 Далі необхідно згенерувати токен для входу в адмін систему Yii2 фреймворка. Для цього необхідно зайти у свій гитхаб та згенерувати там токен доступу.
 

 
Генерація точену у github.com

 
 Результат генерації точену доступу

 
Задаємо отриманий токен у рядок консолі та завантажуємо yii2
 
Створено новий проект yii2 за допомогою composera
 

 
Вікно привітання фреймворку yii2 у браузері
 

Виконуємо ініціалізацію проекту


 
Успішне завершення ініціалізації

Коли всі етапи пройшли успішно, можемо зайти на локальний сервер та почати розробку веб-сайту. Тут ми бачимо, що вже є каркас для нашого сайту. Можемо не робити все з нуля. Продовжимо розробку веб сайту та зробимо додаткову сторінку з інформацією. Для початку заходимо під правами адміністратора.


Вхід під правами адміна
 
Вхід було виконано успішно

Тепер можемо створити декілька файлів для відображення нової інформації на хості.
Перший файл відповідає за інформаційне повідомлення на новій інформаційній сторінці. Другий файл необхідний для того, щоб нову інформацію було видно на сайті.

hello.php:

```<?php
 
/* @var $this yii\web\View */
 
use yii\helpers\Html;
 
$this->title = 'Hello, world!)';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>
 
    <p>
        Hello world, hello <?= $yiiName ?>!
    </p>

<p>
Like any good framework, Yii helps you create modern web applications qu

Алина, [17.11.19 14:53]
ickly, and make sure they perform well. It pushes you to create secure and testable sites by doing a lot of the heavy lifting for you. You can easily use most of its features exactly as they are provided, or you can modify each one to suit your needs. I really encourage you to check it out for your next web project!
</p>
 
    <code><?= FILE ?> -- это можно убрать в коде =))</code>
</div>
main.php:

```<?php

/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">
    <?php
    NavBar::begin([
        'brandLabel' => Yii::$app->name,
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
        ],
    ]);
    echo Nav::widget([
    'options' => ['class' => 'navbar-nav navbar-right'],
    'items' => [
        ['label' => 'Information', 'url' => ['/site/hello']], // ссылка на наш новый фунционал в главном меню
        ['label' => 'Home', 'url' => ['/site/index']],
            ['label' => 'About', 'url' => ['/site/about']],
            ['label' => 'Contact', 'url' => ['/site/contact']],
            Yii::$app->user->isGuest ? (
                ['label' => 'Login', 'url' => ['/site/login']]
            ) : (
                '<li>'
                . Html::beginForm(['/site/logout'], 'post')
                . Html::submitButton(
                    'Logout (' . Yii::$app->user->identity->username . ')',
                    ['class' => 'btn btn-link logout']
                )
                . Html::endForm()
                . '</li>'
            )
        ],
    ]);
    NavBar::end();
    ?>

    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
</div>

<footer class="footer">
    <div class="container">
        <p class="pull-left">&copy; My Company <?= date('Y') ?></p>

        <p class="pull-right"><?= Yii::powered() ?></p>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>

Робочий простір у Codenvy


Робота зі стандартною формою у Yii2


Результат обробки форми Contact


Нова створена сторінка з інформацією

Таким чином, у цьому проекті робота була направлена на створення веб-сайту з корисною інформацією. Для створення цього сайту використовувалася технологія php-фреймворку Yii.

Висновки: було закріплено вміння роботи з php, а також програмними продуктами, за допомогою яких можна розробити веб-сторінки, створення веб-сайту з декількома сторінками, робота з фреймворками.