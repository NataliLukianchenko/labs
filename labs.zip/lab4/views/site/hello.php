<?php
 
/* @var $this yii\web\View */
 
use yii\helpers\Html;
 
$this->title = 'Hello, world!)';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>
 
    <p>
        Hello world, hello <?= $yiiName ?>!
    </p>

<p>
Like any good framework, Yii helps you create modern web applications quickly, and make sure they perform well. It pushes you to create secure and testable sites by doing a lot of the heavy lifting for you. You can easily use most of its features exactly as they are provided, or you can modify each one to suit your needs. I really encourage you to check it out for your next web project!
</p>
 
    <code><?= __FILE__ ?> -- ��� ����� ������ � ���� =))</code>
</div>